# IndyNova Store — Enhanced Version
यह पूरी तरह अपग्रेड किया हुआ प्रोजेक्ट है।
GitHub पर अपलोड करने के लिए तैयार।

Features:
- Home page
- App list + categories
- Upload page
- Login / Signup UI
- Developer dashboard
- Admin panel UI
- Ads placeholders
- Dark mode support
- Responsive UI
